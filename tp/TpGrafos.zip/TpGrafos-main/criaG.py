from igraph import *

def criaG(): #Vai ser realamente necessário? Resposta: N, n vai
  g = Graph()
  g = g.Read_Ncol("/content/lau15.ncol", names=True, directed=False)
  g.vs['name'] = [v.index for v in g.vs()]

  return g
