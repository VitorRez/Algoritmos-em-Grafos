import numpy as np

def criaMatriz():
  matriz = np.loadtxt("lau15_dist.txt", dtype=int)

  return matriz