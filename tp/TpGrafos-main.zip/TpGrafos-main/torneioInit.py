#Função, possivelmente incompleta 
def torneioInit(tam, matriz):
  #O melhor caminho para esse grafo é: [1,13, 2, 15, 9, 5, 7, 3, 12, 14, 10, 8, 6, 4, 11] -> 291
  
  for a in range(20):
    c1 = permut(tam)
    c2 = permut(tam)

    while c1 == c2:
      #del c2
      c2 = permut(tam)

    dist1 = 0
    for i in range(0, tam):
      j = i+1
       if j >= tam:
        break
      
       dist1 += matriz[c1[i]][c1[j]]
    dist1 += matriz[c1[tam-1]][c1[0]]

    dist2 = 0
    for i in range(0, len(c1)-1):
      j = i+1
      if j >= tam:
        break
        
      dist2 += matriz[c2[i]][c2[j]]
    dist2 += matriz[c2[tam-1]][c2[0]]


    if dist1 < dist2:
      v.append(c1)
    else:
      v.append(c2)

  return v
