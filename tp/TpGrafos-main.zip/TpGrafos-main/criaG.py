def criaG(): #Vai ser realamente necessário? Resposta: N, n vai
  g = Graph()
  g = g.Read_Ncol("/content/lau15.ncol", names=True, directed=False)
  g2.vs['name'] = [v.index for v in g2.vs()]

  return g
