import numpy as np

def criaMatrix():
  matrix = np.loadtxt("lau15_dist.txt", dtype=int)

  return matrix
